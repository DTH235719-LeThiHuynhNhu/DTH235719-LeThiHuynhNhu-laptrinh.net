﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai2._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnHienThi_Click(object sender, EventArgs e)
        {
           MessageBox.Show("Chao mung ban den voi mon hoc LAP TRINH.NET");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnHienThi_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Chao mung ban den voi mon hoc LAP TRINH.NET");
        }
    }
}
