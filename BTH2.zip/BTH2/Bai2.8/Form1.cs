﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai2._8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnTong_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtA.Text);
                int b = int.Parse(txtB.Text);
                int tong = a + b;

                txtKetQua.Text = tong.ToString();
            }
            catch
            {
                MessageBox.Show("Vui long nhap so nguyen hop le!");
            }
        }

        private void btnHieu_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtA.Text);
                int b = int.Parse(txtB.Text);
                int hieu = a - b;

                txtKetQua.Text = hieu.ToString();
            }
            catch
            {
                MessageBox.Show("Vui long nhap so nguyen hop le!");
            }
        }

        private void btnTich_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtA.Text);
                int b = int.Parse(txtB.Text);
                int tich = a * b;

                txtKetQua.Text = tich.ToString();
            }
            catch
            {
                MessageBox.Show("Vui long nhap so nguyen hop le!");
            }
        }

        private void btnThuong_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtA.Text);
                int b = int.Parse(txtB.Text);
                int thuong = a / b;

                txtKetQua.Text = thuong.ToString();
            }
            catch
            {
                MessageBox.Show("Vui long nhap so nguyen hop le!");
            }
        }
    }
}